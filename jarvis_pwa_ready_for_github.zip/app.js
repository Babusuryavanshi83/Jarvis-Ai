// Simple offline PWA frontend demo for Jarvis (no server).
// It stores a dummy token locally to simulate login, and echoes commands.
// For full features, use the server package (YouTube/Gmail/etc.).

function init(){
  document.getElementById('registerBtn').addEventListener('click', register);
  document.getElementById('loginBtn').addEventListener('click', login);
  document.getElementById('micBtn').addEventListener('click', startVoice);
  document.getElementById('sendBtn').addEventListener('click', sendCommand);
  document.getElementById('logoutBtn').addEventListener('click', logout);
  const owner = localStorage.getItem('jarvis_owner');
  const token = localStorage.getItem('jarvis_token');
  if(owner && token){ showApp(owner); }
}

function register(){
  const owner = document.getElementById('owner').value.trim();
  const pin = document.getElementById('pin').value.trim();
  if(!owner || !pin){ document.getElementById('loginMsg').innerText='Owner and PIN required'; return; }
  localStorage.setItem('jarvis_owner', owner);
  localStorage.setItem('jarvis_token', 'demo-token');
  document.getElementById('loginMsg').innerText='Registered locally (demo).';
  showApp(owner);
}

function login(){
  const owner = document.getElementById('owner').value.trim();
  const pin = document.getElementById('pin').value.trim();
  const stored = localStorage.getItem('jarvis_owner');
  if(stored && stored===owner){ localStorage.setItem('jarvis_token','demo-token'); showApp(owner); }
  else { document.getElementById('loginMsg').innerText='No such local owner. Register first.'; }
}

function showApp(owner){
  document.getElementById('loginBox').hidden = true;
  document.getElementById('appBox').hidden = false;
  document.getElementById('response').innerText = 'Welcome, ' + owner + '! (demo Jarvis)';
}

function logout(){
  localStorage.removeItem('jarvis_token');
  localStorage.removeItem('jarvis_owner');
  location.reload();
}

function startVoice(){
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SpeechRecognition){ alert('SpeechRecognition not supported on this browser'); return; }
  const rec = new SpeechRecognition();
  rec.lang = 'en-IN';
  rec.start();
  rec.onresult = (ev)=>{
    const t = ev.results[0][0].transcript;
    document.getElementById('command').value = t;
    sendCommand();
  };
  rec.onerror = ()=>{ console.log('voice error'); };
}

function sendCommand(){
  const cmd = document.getElementById('command').value.trim();
  if(!cmd) return;
  // Demo behaviour: echo and simple simulated actions
  const out = document.getElementById('response');
  if(cmd.toLowerCase().includes('youtube')){
    out.innerText = 'Demo: Prepare video upload (requires server OAuth).';
    speak('Preparing video upload. Please configure server.');
    return;
  }
  if(cmd.toLowerCase().includes('report')){
    out.innerText = 'Demo report: No server connected. Use server to fetch income.';
    speak('Report ready. No server connected.');
    return;
  }
  out.innerText = 'Jarvis (demo) heard: ' + cmd;
  speak('I heard: ' + cmd);
}

function speak(text){
  const u = new SpeechSynthesisUtterance(text);
  u.lang = 'en-IN';
  speechSynthesis.cancel();
  speechSynthesis.speak(u);
}

window.addEventListener('load', init);
